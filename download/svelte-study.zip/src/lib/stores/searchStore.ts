import usersStore from './usersStore';
import axios from 'axios';
import { axiosError } from './common';

class SearchStore {
  searchRead(q: string) {
    const url = '/api/v1/search?q=' + q;
    axios.get(url).then((response) => {
      console.log('Done searchRead', response);
      usersStore.users.set(response.data.users);
    }).catch((error) => {
      axiosError(error);
    });
  }
}

export default new SearchStore();
