export const axiosError = (error: any) => {
  console.error(error.response || error.message || error);
};
