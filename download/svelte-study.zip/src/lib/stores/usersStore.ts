import { writable } from 'svelte/store';
import axios from 'axios';
import { axiosError } from './common';

interface User {
  name: string;
  age: string;
}

class UsersStore {
  users = writable([] as User[]);
  user = writable({
    name: '',
    age: ''
  } as User);

  usersCreate(user: User) {
    axios.post('/api/v1/users', user).then((response) => {
      console.log('Done usersCreate', response);
      this.usersRead();
    }).catch((error) => {
      axiosError(error);
    });
  };

  usersRead() {
    axios.get('/api/v1/users').then((response) => {
      console.log('Done usersRead', response);
      this.users.set(response.data.users);
    }).catch((error) => {
      axiosError(error);
    });
  };

  usersDelete(index: number) {
    axios.delete('/api/v1/users/' + index).then((response) => {
      console.log('Done usersDelete', response);
      this.usersRead();
    }).catch((error) => {
      axiosError(error);
    });
  };

  usersUpdate(index: number, user: User) {
    axios.patch('/api/v1/users/' + index, user).then((response) => {
      console.log('Done usersUpdate', response);
      this.usersRead();
    }).catch((error) => {
      axiosError(error);
    });
  };
}


export default new UsersStore();
