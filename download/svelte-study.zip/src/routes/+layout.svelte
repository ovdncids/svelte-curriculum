<script lang="ts">
	import favicon from '$lib/assets/favicon.svg';
	import Header from './Header.svelte';
	import Nav from './Nav.svelte';
	import Footer from './Footer.svelte';
	let { children } = $props();
</script>

<svelte:head>
	<link rel="icon" href={favicon} />
	<link rel="stylesheet" href="/css/global.css" />
</svelte:head>

<div id="app">
  {#if true}
  <Header />
  {/if}
  <hr />
  <div class="container">
    <Nav />
    <hr />
    <section class="contents">
      {@render children?.()}
    </section>
    <hr />
  </div>
  <Footer title={'카피라이트'} />
</div>
