<script lang="ts">
  export let title: string;
</script>

<footer>{title || 'Copyright'}</footer>
