<script lang="ts">
  import usersStore from '$lib/stores/usersStore';
  import searchStore from '$lib/stores/searchStore';
  import { goto } from '$app/navigation';
  import { getStores } from '$app/stores';

  const {users} = usersStore;
  console.log($users);

  let q = '';
  const searchRead = (event: Event) => {
    event.preventDefault();
    goto('/search?q=' + q);
  };

  const watchQuerystring = (querystring: string) => {
    q = new URLSearchParams(querystring).get('q') || '';
    searchStore.searchRead(q);
  }
  const { page } = getStores();
  $: watchQuerystring($page.url.searchParams.toString());
</script>

<div>
  <h3>Search</h3>
  <hr class="d-block" />
  <div>
    <form on:submit="{(event) => searchRead(event)}">
      <input type="text" placeholder="Search" bind:value={q} />
      <button>Search</button>
    </form>
  </div>
  <hr class="d-block" />
  <div>
    <table class="table-search">
      <thead>
        <tr>
          <th>Name</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>
      {#each $users as user, index}
        <tr>
          <td>{user.name}</td>
          <td>{user.age}</td>
        </tr>
      {/each}
      </tbody>
    </table>
  </div>
</div>
