<script lang="ts">
  import usersStore from '$lib/stores/usersStore';
  const {users, user} = usersStore;
  console.log($users, $user);
  usersStore.usersRead();
</script>

<div>
  <h3>Users</h3>
  <hr class="d-block" />
  <div>
    <h4>Read</h4>
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Age</th>
          <th>Modify</th>
        </tr>
      </thead>
      <tbody>
        {#each $users as user, index}
          <tr>
            <td><input type="text" placeholder="Name" bind:value={user.name} /></td>
            <td><input type="text" placeholder="Age" bind:value={user.age} /></td>
            <td>
              <button on:click="{() => usersStore.usersUpdate(index, user)}">Update</button>
              <button on:click="{() => usersStore.usersDelete(index)}">Delete</button>
            </td>
          </tr>
        {/each}
      </tbody>
    </table>
  </div>
  <hr class="d-block" />
  <div>
    <h4>Create</h4>
    <input type="text" placeholder="Name" bind:value={$user.name} />
    <input type="text" placeholder="Age" bind:value={$user.age} />
    <button on:click={() => usersStore.usersCreate($user)}>Create</button>
  </div>
</div>
