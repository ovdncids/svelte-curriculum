<script lang="ts">
  import { getStores } from '$app/stores';
  const { page } = getStores();
</script>

<nav class="nav">
  <ul>
    <li><h2><a href="/users" class:active={$page.url.pathname === '/users'}>Users</a></h2></li>
    <li><h2><a href="/search" class:active={$page.url.pathname === '/search'}>Search</a></h2></li>
  </ul>
</nav>
