<header>
  <h1>Svelte study</h1>
</header>
