<script>
import membersStore from '../../store/membersStore.js';
import searchStore from '../../store/searchStore.js';
import {push, querystring} from 'svelte-spa-router';

const {members} = membersStore;
let q = '';
const searchRead = (event) => {
  event.preventDefault();
  push('/search?q=' + q);
};
const watchQuerystring = (querystring) => {
  q = new URLSearchParams(querystring).get('q') || '';
  searchStore.searchRead(q);
}
$: watchQuerystring($querystring);
</script>

<div>
  <h3>Search</h3>
  <hr class="d-block" />
  <div>
    <form on:submit="{(event) => searchRead(event)}">
      <input type="text" placeholder="Search" bind:value={q} />
      <button>Search</button>
    </form>
  </div>
  <hr class="d-block" />
  <div>
    <table class="table-search">
      <thead>
        <tr>
          <th>Name</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>
      {#each $members as member, index}
        <tr>
          <td>{member.name}</td>
          <td>{member.age}</td>
        </tr>
      {/each}
      </tbody>
    </table>
  </div>
</div>
