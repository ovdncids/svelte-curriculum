<script>
import {replace} from 'svelte-spa-router';

replace('/members');
</script>
