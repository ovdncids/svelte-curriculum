import axios from 'axios';
import { axiosError } from './common.js';
import membersStore from './membersStore.js';

class SearchStore {
  searchRead(q) {
    const url = `/api/v1/search?q=${q}`;
    axios.get(url).then((response) => {
      console.log('Done searchRead', response);
      membersStore.members.set(response.data.members);
    }).catch((error) => {
      axiosError(error);
    });
  }
}

export default new SearchStore();
